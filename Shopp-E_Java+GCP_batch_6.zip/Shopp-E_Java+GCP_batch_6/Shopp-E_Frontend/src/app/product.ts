export class Product {

    id: String | any;
    name: String | any;
    brand: string | any;
    madein: string | any;
    imgpath: String |any;
    category: String |any;
    price:number =0;
    active: boolean | any;
    Quantity :number = 1;
    total : number = 0;
}
