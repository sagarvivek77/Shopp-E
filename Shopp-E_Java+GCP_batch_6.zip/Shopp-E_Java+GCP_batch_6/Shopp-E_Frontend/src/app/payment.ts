export class Payment {

    id :string | any;
    noc:string | any;
    cardno:string | any;
    expiry: Date | any;
    cvv:number = 0;
    street:string| any;
    city:string| any;
    state:string|any;
    pincode:number=0;
}
