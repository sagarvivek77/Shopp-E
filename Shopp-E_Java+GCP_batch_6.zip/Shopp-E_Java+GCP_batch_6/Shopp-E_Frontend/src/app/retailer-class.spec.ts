import { RetailerClass } from './retailer-class';

describe('RetailerClass', () => {
  it('should create an instance', () => {
    expect(new RetailerClass()).toBeTruthy();
  });
});
